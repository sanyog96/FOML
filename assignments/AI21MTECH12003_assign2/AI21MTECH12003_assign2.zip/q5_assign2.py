import numpy as np
import pandas as pd
from sklearn.svm import SVC

feature_train_data_url='https://archive.ics.uci.edu/ml/machine-learning-databases/gisette/GISETTE/gisette_train.data'
label_train_data_url='https://archive.ics.uci.edu/ml/machine-learning-databases/gisette/GISETTE/gisette_train.labels'
#feature_test_data_url='https://archive.ics.uci.edu/ml/machine-learning-databases/gisette/GISETTE/gisette_test.data'
#label_test_data_url='https://archive.ics.uci.edu/ml/machine-learning-databases/gisette/GISETTE/gisette_test.labels'
feature_test_data_url='https://archive.ics.uci.edu/ml/machine-learning-databases/gisette/GISETTE/gisette_valid.data'
label_test_data_url='https://archive.ics.uci.edu/ml/machine-learning-databases/gisette/gisette_valid.labels'

feature_train_data = np.genfromtxt(feature_train_data_url)
label_train_data = np.genfromtxt(label_train_data_url)
feature_test_data = np.genfromtxt(feature_test_data_url)
label_test_data = np.genfromtxt(label_test_data_url)

def train(feature_train_data, label_train_data, cost, kernel, gamma, degree, coef=0):
    model = SVC(C=cost, kernel=kernel, gamma=gamma, degree=degree, coef0=coef)
    model.fit(feature_train_data, label_train_data)
    return model, model.support_.shape[0]
    
def predict(data, label, model):
    predict = model.predict(data)
    num_of_supp_vctrs = predict.shape[0]
    return 1 - np.sum(predict!=label)/(num_of_supp_vctrs)

def q5a(cost, kernel, gamma, degree):
    svm_model, num_of_supp_vctrs = train(feature_train_data, label_train_data, cost, kernel, gamma, degree)
    test_accuracy = predict(feature_test_data, label_test_data, svm_model)
    train_accuracy = predict(feature_train_data, label_train_data, svm_model)
    print("q5a linear model test error: " + str(1-test_accuracy) + " ; train error : " + str(1-train_accuracy) + " ; total number of support vectors: " + str(num_of_supp_vctrs))
    
q5a(1, 'linear', 'auto', 1)

def q5b(cost, kernel, gamma, degree, coef=0):
    svm_model, num_of_supp_vctrs = train(feature_train_data, label_train_data, cost, kernel, gamma, degree, coef)
    test_accuracy = predict(feature_test_data, label_test_data, svm_model)
    train_accuracy = predict(feature_train_data, label_train_data, svm_model)
    print("q5b " + str(kernel) + " model test error: " + str(1-test_accuracy) + " ; train error: " + str(1-train_accuracy) + " ; total number of support vectors: " + str(num_of_supp_vctrs))

q5b(1, 'rbf', 0.001, 2)
q5b(1, 'poly', 1, 2, 1)
