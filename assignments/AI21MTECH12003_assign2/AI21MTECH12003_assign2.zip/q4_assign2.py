import numpy as np
import pandas as pd
from sklearn.svm import SVC

all_train_data_url='http://www.amlbook.com/data/zip/features.train'
all_test_data_url='http://www.amlbook.com/data/zip/features.test'

train_data_list = np.genfromtxt(all_train_data_url, dtype=float) 
test_data_list = np.genfromtxt(all_test_data_url, dtype=float)

train_data = list(filter(lambda x: x[0] == 1 or x[0] == 5, train_data_list))
test_data = list(filter(lambda x: x[0] == 1 or x[0] == 5, test_data_list))

#def readData(data=train_data):
func1 = lambda x: x[1:3]
func2 = lambda x: x[0]

feature_train_data, label_train_data = np.apply_along_axis(func1, 1, train_data), list(1 if x == 1 else -1 for x in np.apply_along_axis(func2, 1, train_data))
feature_test_data, label_test_data = np.apply_along_axis(func1, 1, test_data), list(1 if x == 1 else -1 for x in np.apply_along_axis(func2, 1, test_data))

def train(feature_train_data, label_train_data, cost, kernel, gamma, degree, coef=0):
    model = SVC(C=cost, kernel=kernel, gamma=gamma, degree=degree, coef0=coef)
    model.fit(feature_train_data, label_train_data)
    return model, model.support_.shape[0]
    
def predict(data, label, model):
    predict = model.predict(data)
    num_of_supp_vctrs = predict.shape[0]
    return 1 - np.sum(predict!=label)/(num_of_supp_vctrs)

def q4a(cost, kernel, gamma, degree):
    svm_model, num_of_supp_vctrs = train(feature_train_data, label_train_data, cost, kernel, gamma, degree)
    accuracy = predict(feature_test_data, label_test_data, svm_model)
    print("q4a linear model test data accuracy: %0.5f and total number of support vectors: %d" % (accuracy, num_of_supp_vctrs))
    
q4a(1, 'linear', 'auto', 1)

def q4b(cost, kernel, gamma, degree):
    for i in [50, 100, 200, 800]:
        subset_feature_data = feature_train_data[:i]
        subset_label_data = label_train_data[:i]
        #print("size of feature data: " + str(len(subset_feature_data)) + " ; label data: " + str(len(subset_label_data)))
        svm_model, num_of_supp_vctrs = train(subset_feature_data, subset_label_data, cost, kernel, gamma, degree)
        accuracy = predict(feature_test_data, label_test_data, svm_model)
        print("q4b linear model training with %d data points gives test accuracy: %0.5f and total number of support vectors: %d" % (i, accuracy, num_of_supp_vctrs))

q4b(1, 'linear', 'auto', 1)

def q4c(cost, kernel, gamma, degree, coef):
    for c in cost:
        for d in degree:
            svm_model, num_of_supp_vctrs = train(feature_train_data, label_train_data, c, kernel, gamma, d, coef)
            test_accuracy = predict(feature_test_data, label_test_data,  svm_model)
            train_accuracy = predict(feature_train_data, label_train_data, svm_model)
            print("q4c polynomial model: C = " + str(c) + " ; Q = " + str(d) + " ; test error: " + str(1-test_accuracy) + " ; train error: " + str(1-train_accuracy) + " ; number of support vectors: " + str(num_of_supp_vctrs))

q4c([0.0001, 0.001, 0.01, 1], 'poly', 1, [2,5], 1)

def q4d(cost, kernel, gamma, degree):
    for c in cost:
        svm_model, num_of_supp_vctrs = train(feature_train_data, label_train_data, c, kernel, gamma, degree)
        test_accuracy = predict(feature_test_data, label_test_data, svm_model)
        train_accuracy = predict(feature_train_data, label_train_data, svm_model)
        print("q4d rbf model: C = " + str(c) + " ; Q = " + str(degree) + " ; test_error: " + str(1-test_accuracy) + " ; train error: " + str(1-train_accuracy))

q4d([0.01, 1, 100, 10000, 1000000], 'rbf', 1, 2)
