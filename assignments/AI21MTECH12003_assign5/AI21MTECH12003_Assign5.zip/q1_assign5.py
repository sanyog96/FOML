# Random Forest Algorithm on Sonar Dataset
from csv import reader
from math import sqrt
import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

def q1a(X, n_clusters):
    #plt.scatter(X[:, 0], X[:, 1],c='white', marker='o',edgecolor='black', s=50)
    #plt.show()
    km = KMeans(n_clusters=n_clusters, init='random',n_init=10, max_iter=300, tol=1e-04, random_state=0)
    y_km = km.fit_predict(X)
    plt.scatter(X[y_km == 0, 0], X[y_km == 0, 1],s=50, c='lightgreen',marker='o', edgecolor='black',label='cluster 1')

    plt.scatter(X[y_km == 1, 0], X[y_km == 1, 1],s=50, c='orange',marker='o', edgecolor='black',label='cluster 2')
    #plt.scatter(km.cluster_centers_[:, 0], km.cluster_centers_[:, 1],s=250, marker='*',c='red', edgecolor='black',label='centroids')
    plt.title('K-means algo')
    plt.legend(scatterpoints=1)
    plt.grid()
    plt.show()

def check_core_point(eps,minPts, df, index):
    #get points from given index
    x, y = df.iloc[index]['X']  ,  df.iloc[index]['Y']
    
    #check available points within radius
    temp =  df[((np.abs(x - df['X']) <= eps) & (np.abs(y - df['Y']) <= eps)) & (df.index != index)]
    
    #check how many points are present within radius
    if len(temp) >= minPts:
        #return format (dataframe, is_core, is_border, is_noise)
        return (temp.index , True, False, False)
    
    elif (len(temp) < minPts) and len(temp) > 0:
        #return format (dataframe, is_core, is_border, is_noise)
        return (temp.index , False, True, False)
    
    elif len(temp) == 0:
        #return format (dataframe, is_core, is_border, is_noise)
        return (temp.index , False, False, True)

def cluster_with_stack(eps, minPts, df):
    
    #initiating cluster number
    C = 1
    #initiating stacks to maintain
    current_stack = set()
    unvisited = list(df.index)
    clusters = []
    
    while (len(unvisited) != 0): #run until all points have been visited

        #identifier for first point of a cluster
        first_point = True
        
        #choose a random unvisited point
        current_stack.add(random.choice(unvisited))
        
        while len(current_stack) != 0: #run until a cluster is complete
            
            #pop current point from stack
            curr_idx = current_stack.pop()
            
            #check if point is core, neighbour or border
            neigh_indexes, iscore, isborder, isnoise = check_core_point(eps, minPts, df, curr_idx)
            
            #dealing with an edge case
            if (isborder & first_point):
                #for first border point, we label it aand its neighbours as noise 
                clusters.append((curr_idx, 0))
                clusters.extend(list(zip(neigh_indexes,[0 for _ in range(len(neigh_indexes))])))
                
                #label as visited
                unvisited.remove(curr_idx)
                unvisited = [e for e in unvisited if e not in neigh_indexes]
    
                continue
                
            unvisited.remove(curr_idx) #remove point from unvisited list
            
            neigh_indexes = set(neigh_indexes) & set(unvisited) #look at only unvisited points
            
            if iscore: #if current point is a core
                first_point = False
                
                clusters.append((curr_idx,C)) #assign to a cluster
                current_stack.update(neigh_indexes) #add neighbours to a stack

            elif isborder: #if current point is a border point
                clusters.append((curr_idx,C))
                
                continue

            elif isnoise: #if current point is noise
                clusters.append((curr_idx, 0))
                
                continue
                
        if not first_point:
            #increment cluster number
            C+=1
        
    return clusters

def q1b(X, eps, minPts):
    data = pd.DataFrame(X, columns = ["X", "Y"] )
    clustered = cluster_with_stack(eps, minPts, data)
    
    idx , cluster = list(zip(*clustered))
    cluster_df = pd.DataFrame(clustered, columns = ["idx", "cluster"])
    
    plt.figure(figsize=(10,7))
    for clust in np.unique(cluster):
        plt.scatter(X[cluster_df["idx"][cluster_df["cluster"] == clust].values, 0], X[cluster_df["idx"][cluster_df["cluster"] == clust].values, 1], s=10, label=f"Cluster{clust}")
    
    plt.legend([f"Cluster {clust}" for clust in np.unique(cluster)], loc ="lower right")
    plt.title('DBSCAN algo')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.show()
    
def q1d(X, n_clusters, eps, minPts):
    #plt.scatter(X[:, 0], X[:, 1],c='white', marker='o',edgecolor='black', s=50)
    #plt.show()
    km = KMeans(n_clusters=n_clusters, init='random',n_init=10, max_iter=300, tol=1e-04, random_state=0)
    y_km = km.fit_predict(X)
    plt.scatter(X[y_km == 0, 0], X[y_km == 0, 1],s=50, c='lightgreen',marker='o', edgecolor='black',label='cluster 1')
    
    plt.scatter(X[y_km == 1, 0], X[y_km == 1, 1],s=50, c='orange',marker='o', edgecolor='black',label='cluster 2')
    plt.scatter(X[y_km == 2, 0], X[y_km == 2, 1],s=50, c='red',marker='o', edgecolor='black',label='cluster 3')
    #plt.scatter(km.cluster_centers_[:, 0], km.cluster_centers_[:, 1],s=250, marker='*',c='red', edgecolor='black',label='centroids')
    plt.title('K-means algo')
    plt.legend(scatterpoints=1)
    plt.grid()
    plt.show()
    q1b(X, eps, minPts)

# load and prepare data
filename1 = 'dataset1.txt'
dataset1 = np.genfromtxt(filename1)

filename2 = 'dataset2.txt'
dataset2 = np.genfromtxt(filename2)
#dataset = pd.read_csv(filename)

print("q1a")
q1a(dataset1, 2)
print("q1b")
q1b(dataset1, 0.2, 3)
print("q1d")
q1d(dataset2, 3, 3, 5)