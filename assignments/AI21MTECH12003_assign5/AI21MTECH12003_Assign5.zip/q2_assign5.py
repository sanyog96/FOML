# Random Forest Algorithm on Sonar Dataset
from csv import reader
from math import sqrt
import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.datasets import load_digits

digits = load_digits()
X = digits.data[:]
y = digits.target[:]

def train(X, y, n_iter, title):
    tsne = TSNE(n_components=2, n_iter=n_iter, random_state=0)
    X_2d = tsne.fit_transform(X)
    plt.scatter(X_2d[:, 0], X_2d[:, 1], c=y)
    plt.title(title)
    plt.show()
    
def q2a(X, y):
    for i in [250, 1000, 2000]:
        title = "t-SNE plot with number of iterations: " + str(i)
        train(X, y, i, title)

print("q2a")
q2a(X, y)
