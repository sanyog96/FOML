# Random Forest Algorithm on Sonar Dataset
from random import randrange
from csv import reader
from math import sqrt
import numpy as np
from sklearn.model_selection import train_test_split as tts
from sklearn.ensemble import RandomForestClassifier as RFC
from datetime import datetime
import matplotlib.pyplot as plt

def float_column_to_int(dataset, column):
    for row in dataset:
        row[column] = int(row[column])

# Calculate accuracy percentage
def accuracy_metric(actual, predicted):
	correct = 0
	for i in range(len(actual)):
		if actual[i] == predicted[i]:
			correct += 1
	return correct / float(len(actual)) * 100.0

# Split a dataset based on an attribute and an attribute value
def test_split(index, value, dataset):
	left, right = list(), list()
	for row in dataset:
		if row[index] < value:
			left.append(row)
		else:
			right.append(row)
	return left, right

# Calculate the Gini index for a split dataset
def gini_index(groups, classes):
	# count all samples at split point
	n_instances = float(sum([len(group) for group in groups]))
	# sum weighted Gini index for each group
	gini = 0.0
	for group in groups:
		size = float(len(group))
		# avoid divide by zero
		if size == 0:
			continue
		score = 0.0
		# score the group based on the score for each class
		for class_val in classes:
			p = [row[-1] for row in group].count(class_val) / size
			score += p * p
		# weight the group score by its relative size
		gini += (1.0 - score) * (size / n_instances)
	return gini

# Select the best split point for a dataset
def get_split(dataset, n_features):
	class_values = list(set(row[-1] for row in dataset))
	b_index, b_value, b_score, b_groups = 999, 999, 999, None
	features = list()
	while len(features) < n_features:
		index = randrange(len(dataset[0])-1)
		if index not in features:
			features.append(index)
	for index in features:
		for row in dataset:
			groups = test_split(index, row[index], dataset)
			gini = gini_index(groups, class_values)
			if gini < b_score:
				b_index, b_value, b_score, b_groups = index, row[index], gini, groups
	return {'index':b_index, 'value':b_value, 'groups':b_groups}

# Create a terminal node value
def to_terminal(group):
	outcomes = [row[-1] for row in group]
	return max(set(outcomes), key=outcomes.count)

# Create child splits for a node or make terminal
def split(node, max_depth, min_size, n_features, depth):
	left, right = node['groups']
	del(node['groups'])
	# check for a no split
	if not left or not right:
		node['left'] = node['right'] = to_terminal(left + right)
		return
	# check for max depth
	if depth >= max_depth:
		node['left'], node['right'] = to_terminal(left), to_terminal(right)
		return
	# process left child
	if len(left) <= min_size:
		node['left'] = to_terminal(left)
	else:
		node['left'] = get_split(left, n_features)
		split(node['left'], max_depth, min_size, n_features, depth+1)
	# process right child
	if len(right) <= min_size:
		node['right'] = to_terminal(right)
	else:
		node['right'] = get_split(right, n_features)
		split(node['right'], max_depth, min_size, n_features, depth+1)

# Build a decision tree
def build_tree(train, max_depth, min_size, n_features):
	root = get_split(train, n_features)
	split(root, max_depth, min_size, n_features, 1)
	return root

# Make a prediction with a decision tree
def predict(node, row):
	if row[node['index']] < node['value']:
		if isinstance(node['left'], dict):
			return predict(node['left'], row)
		else:
			return node['left']
	else:
		if isinstance(node['right'], dict):
			return predict(node['right'], row)
		else:
			return node['right']

def setdiff2d_idx(arr1, arr2):
    delta = set(map(tuple, arr2))
    idx = [tuple(x) not in delta for x in arr1]
    return arr1[idx]

# Create a random subsample from the dataset with replacement
def subsample(dataset, ratio):
    sample = list()
    n_sample = round(len(dataset) * ratio)
    while len(sample) < n_sample:
    	index = randrange(len(dataset))
    	sample.append(dataset[index])
    remaining_dataset = setdiff2d_idx(dataset, sample)
    return sample, remaining_dataset

# Make a prediction with a list of bagged trees
def bagging_predict(trees, row):
    predictions = [predict(tree, row) for tree in trees]
    return max(set(predictions), key=predictions.count)

# Random Forest Algorithm
def random_forest(trainset, testset, max_depth, min_size, sample_size, n_trees, n_features):
    trees = list()
    for i in range(n_trees):
        sample, remaining_dataset = subsample(trainset, sample_size)
        tree = build_tree(sample, max_depth, min_size, n_features)
        trees.append(tree)
    predictions = [bagging_predict(trees, row) for row in testset]
    actual = [row[-1] for row in testset]
    accuracy = accuracy_metric(actual, predictions)
    return accuracy

def random_forest_oob(trainset, testset, max_depth, min_size, sample_size, n_trees, n_features):
    trees = list()
    oob_accuracies = list()
    for i in range(n_trees):
        sample, remaining_dataset = subsample(trainset, sample_size)
        tree = build_tree(sample, max_depth, min_size, n_features)
        prediction_each_tree = [predict(tree, row) for row in remaining_dataset]
        actual = [row[-1] for row in remaining_dataset]
        oob_accuracies.append(accuracy_metric(actual, prediction_each_tree))
        trees.append(tree)
    predictions = [bagging_predict(trees, row) for row in testset]
    actual = [row[-1] for row in testset]
    accuracy = accuracy_metric(actual, predictions)
    return accuracy, oob_accuracies

def q4a(dataset, max_depth, min_size, sample_size, n_trees):
    n_features = int(sqrt(len(dataset[0])-1))
    trainset,testset = tts(dataset, test_size=0.3, train_size=0.7)
    print("implemented random forest starting at: " + str(datetime.now()))
    accuracy1 = random_forest(trainset, testset, max_depth, min_size, sample_size, n_trees, n_features)
    print("implemented random forest ending at: " + str(datetime.now()))
    test_features, test_label, train_features, train_label = list(), list(), list(), list()
    for row in trainset:
        train_label.append(row[-1])
        train_features.append(row[0:(len(row)-1)])
    for row in testset:
        test_label.append(row[-1])
        test_features.append(row[0:(len(row)-1)])
    print("in-built random forest starting at: " + str(datetime.now()))
    model = RFC(n_estimators=n_trees, max_depth=max_depth, max_features='sqrt')
    model.fit(train_features, train_label)
    predictions = model.predict(test_features)
    accuracy2 = accuracy_metric(test_label, predictions)
    print("in-built random forest ending at: " + str(datetime.now()))
    print("user built random forest accuracy for m: %d : %0.3f" % (n_features, accuracy1))
    print("in built random forest accuracy for m: %d : %0.3f" % (n_features, accuracy2))

def q4b(dataset, max_depth, min_size, sample_size, n_trees):
    trainset,testset = tts(dataset, test_size=0.3, train_size=0.7)
    for n_features in [int(sqrt(len(dataset[0])-1)), int(sqrt(len(dataset[0])-1)/2), int(2 * sqrt(len(dataset[0])-1))]:
        print("accuracy for m: %d : %0.3f" % (n_features, random_forest(trainset, testset, max_depth, min_size, sample_size, n_trees, n_features)))

def q4c(dataset, max_depth, min_size, sample_size, n_trees):
    trainset,testset = tts(dataset, test_size=0.3, train_size=0.7)
    m = [1, 4, 7, 10, 13, 16, 19, 22]
    accuracies = list()
    oob = list()
    for n_features in m:
        accuracy, oob_accuracies = random_forest_oob(trainset, testset, max_depth, min_size, sample_size, n_trees, n_features)
        print("error rate and oob error for m: %d : \t%0.3f \tand \t%0.3f" % (n_features, 100 - accuracy, 100 - (np.sum(oob_accuracies)/len(oob_accuracies))))
        accuracies.append(100 - accuracy)
        oob.append(100 - (np.sum(oob_accuracies)/len(oob_accuracies)))
    plt.plot(m, accuracies, label='test error')
    plt.plot(m, oob, label='oob error')
    plt.xlabel("m")
    plt.ylabel("error(%)")
    plt.legend()
    plt.show()

# load and prepare data
dataset_url = 'https://web.stanford.edu/~hastie/ElemStatLearn//datasets/spam.data'
dataset = np.genfromtxt(dataset_url, dtype=float)
float_column_to_int(dataset, len(dataset[0]) - 1)
max_depth = 10
min_size = 1
sample_size = 0.5
n_trees = 10
#n_features = int(sqrt(len(dataset[0])-1))

print("q4a")
q4a(dataset, max_depth, min_size, sample_size, n_trees)
print("q4b")
q4b(dataset, max_depth, min_size, sample_size, n_trees)
print("q4c")
q4c(dataset, max_depth, min_size, sample_size, n_trees)
