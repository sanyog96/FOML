# Random Forest Algorithm on Sonar Dataset
from random import randrange
from csv import reader
from math import sqrt
import numpy as np
from sklearn.model_selection import train_test_split as tts
from sklearn.ensemble import GradientBoostingClassifier as GBC
from sklearn.tree  import DecisionTreeClassifier as DTC
from datetime import datetime
import pandas as pd

def features_n_labels(filename):
    dataset = pd.read_csv(filename)
    dataset_features = dataset[dataset['loan_status'] != 'Current']
    #dataset_labels = [1 if i == 'Fully Paid' else -1 if i == 'Charged Off' else i for i in list(filter(lambda x: x != 'Current', dataset['loan_status']))]
    narrowed_dataset_features = dataset_features.iloc[:, :49]
    narrowed_dataset_features = narrowed_dataset_features.drop(["grade", "mths_since_last_delinq", "mths_since_last_record","next_pymnt_d", "sub_grade", "emp_title", "pymnt_plan","url","desc","title","initial_list_status","out_prncp","out_prncp_inv","purpose","zip_code","addr_state","issue_d","earliest_cr_line","last_pymnt_d","last_credit_pull_d"], axis=1)
    #"purpose","zip_code","addr_state"
    narrowed_dataset_features['term'].replace({" 36 months": "36", " 60 months": "60"}, inplace=True)
    narrowed_dataset_features['emp_length'].replace({"10+ years": "10", "1 year": "1", "2 years": "2", "3 years": "3", "4 years": "4", "5 years": "5", "8 years": "8", "6 years": "6", "7 years": "7", "9 years": "9", "< 1 year": "0", "n/a": "-1"}, inplace=True)
    narrowed_dataset_features.dropna(inplace=True)
    #narrowed_dataset_features['home_ownership'].replace({"RENT": "0", "OWN": "1", "MORTGAGE": "2", "OTHER": "3", "NONE": "-1"}, inplace=True)
    narrowed_dataset_features['home_ownership'].replace({"RENT": "-1", "OWN": "1", "MORTGAGE": "-1", "OTHER": "-1", "NONE": "-1"}, inplace=True)
    narrowed_dataset_features['verification_status'].replace({"Not Verified": "-1", "Source Verified": "1", "Verified": "1"}, inplace=True)
    #narrowed_dataset_features['grade'].replace({"A": "0", "B": "1", "C": "2", "D": "3", "E": "4", "F": "5", "G": "6"}, inplace=True)
    narrowed_dataset_features['int_rate'] = narrowed_dataset_features['int_rate'].map(lambda x: x.rstrip('%'))
    narrowed_dataset_features['revol_util'] = narrowed_dataset_features['revol_util'].map(lambda x: x.rstrip('%') if isinstance(x, str) else x)
    narrowed_dataset_features['int_rate'] = narrowed_dataset_features['int_rate'].map(lambda x: x.rstrip('%'))
    dataset_labels = [1 if i == 'Fully Paid' else -1 if i == 'Charged Off' else i for i in list(filter(lambda x: x != 'Current', narrowed_dataset_features['loan_status']))]
    #print(narrowed_dataset_features.shape)
    #print(len(dataset_labels))
    narrowed_dataset_features = narrowed_dataset_features.drop("loan_status", axis=1)
    narrowed_dataset_features = narrowed_dataset_features.to_numpy()
    return narrowed_dataset_features, dataset_labels

trainset_features, trainset_labels = features_n_labels('loan_train.csv')
testset_features, testset_labels = features_n_labels('loan_test.csv')

def confusion_matrix(predictions, labels):
    conf_matrix = [[0, 0], [0, 0]]
    for i in range(len(predictions)):
        if predictions[i] == labels[i]:
            if(labels[i] == 1):
                conf_matrix[0][0] = conf_matrix[0][0] + 1
            elif(labels[i] == -1):
                conf_matrix[1][1] = conf_matrix[1][1] + 1
            else:
                continue
        else: #predictions[i] != labels[i]:
            if(labels[i] == -1):
                conf_matrix[0][1] = conf_matrix[0][1] + 1
            elif(labels[i] == 1):
                conf_matrix[1][0] = conf_matrix[1][0] + 1
            else:
                continue
    return conf_matrix

def gradient_boost_clss(trainset_features, testset_features, trainset_labels, testset_labels, n_estimators):
    model = GBC(max_depth=10, n_estimators=n_estimators)
    model.fit(trainset_features, trainset_labels)
    predictions = model.predict(testset_features)
    conf_matrix = confusion_matrix(predictions, testset_labels)
    return conf_matrix, (1 - np.sum(predictions!=testset_labels)/(predictions.shape[0]))

def decision_tree(trainset_features, testset_features, trainset_labels, testset_labels):
    model = DTC(criterion ="entropy", max_depth=10)
    model.fit(trainset_features, trainset_labels)
    predictions = model.predict(testset_features)
    conf_matrix = confusion_matrix(predictions, testset_labels)
    return conf_matrix, (1 - np.sum(predictions!=testset_labels)/(predictions.shape[0]))

def q5bb(trainset_features, testset_features, trainset_labels, testset_labels):
    for i in [5,10,20,50,70,100]:
        conf_matrix, accuracy = gradient_boost_clss(trainset_features,  testset_features, trainset_labels, testset_labels, i)
        print("accuracy for trees count: %d : %0.4f" % (i, accuracy*100))

def q5bc(trainset_features, testset_features, trainset_labels, testset_labels):
    conf_matrix1, accuracy1 = gradient_boost_clss(trainset_features,  testset_features, trainset_labels, testset_labels, 100)
    conf_matrix2, accuracy2 = decision_tree(trainset_features,  testset_features, trainset_labels, testset_labels)
    print("accuracy, precision and recall for gradient boost classifier: \t%0.4f \t%0.4f \t%0.4f" % (accuracy1, conf_matrix1[0][0]/(conf_matrix1[0][0] + conf_matrix1[1][0]), conf_matrix1[0][0]/(conf_matrix1[0][0] + conf_matrix1[0][1])))
    print("accuracy, precision and recall for decision tree classifier: \t%0.4f \t%0.4f \t%0.4f" % (accuracy2, conf_matrix2[0][0]/(conf_matrix2[0][0] + conf_matrix2[1][0]), conf_matrix2[0][0]/(conf_matrix2[0][0] + conf_matrix2[0][1])))

q5bb(trainset_features, testset_features, trainset_labels, testset_labels)
q5bc(trainset_features, testset_features, trainset_labels, testset_labels)
