# FoML Assign 1 Code Skeleton
# Please use this outline to implement your decision tree. You can add any code around this.

import csv
import pandas as pd
import numpy as np

# Enter You Name Here
myname = "AI21MTECH12003" # or "Amar-Akbar-Antony"

def entropy(target_column):
    elements,counts = np.unique(target_column,return_counts = True)
    entropy = np.sum([(-counts[i]/np.sum(counts))*np.log2(counts[i]/np.sum(counts)) for i in range(len(elements))])
    return entropy

def infoGain(data,split_column,target_column="quality"):
    total_entropy = entropy(data[target_column])
    vals,counts= np.unique(data[split_column],return_counts=True)
    Weighted_Entropy = np.sum([(counts[i]/np.sum(counts)) * entropy(data.where(data[split_column]==vals[i]).dropna()[target_column]) for i in range(len(vals))])
    Information_Gain = total_entropy - Weighted_Entropy
    return Information_Gain
    
def giniIndex(target_column):
    elements,counts = np.unique(target_column,return_counts = True)
    index = np.sum([((counts[i]/np.sum(counts))*(counts[i]/np.sum(counts))) for i in range(len(elements))])
    return index

def giniIndexTotal(data,split_column,target_column="quality"):
    vals,counts= np.unique(data[split_column],return_counts=True)
    total_index = 1 - np.sum([giniIndex(data.where(data[split_column]==vals[i]).dropna()[target_column]) for i in range(len(vals))])
    return total_index

# Implement your decision tree below
class DecisionTree():

    def __init__(self):
        self.tree = {}
    
    def train(self, data_set, data, org_data, features_columns, method, target_column='quality', parent_node=None):
        if len(np.unique(data[target_column])) <= 1:
            return np.unique(data[target_column])[0]

        elif len(data)==0:
            return np.unique(org_data[target_column])[np.argmax(np.unique(org_data[target_column],return_counts=True)[1])]

        elif len(features_columns) ==0:
            return parent_node

        else:
            parent_node = np.unique(data[target_column])[np.argmax(np.unique(data[target_column],return_counts=True)[1])]
            if method == 'entropy':
                item_values = [infoGain(data,feature,target_column) for feature in features_columns]
            else:
                item_values = [giniIndexTotal(data,feature,target_column) for feature in features_columns]
            best_feature_index = np.argmax(item_values)
            #print("best_feature_index: %d" % best_feature_index)
            #print(features_columns)
            best_feature = features_columns[best_feature_index]
        
            tree_temp = {best_feature:{}}
        
            features_columns = [i for i in features_columns if i != best_feature]
        
            for value in np.unique(data[best_feature]):
                value = value
                sub_data = data.where(data[best_feature] == value).dropna() 
                subtree = self.train(data_set, sub_data, data_set, features_columns, method, target_column, parent_node)
                tree_temp[best_feature][value] = subtree
            
            return(tree_temp)    

    def learn(self, data_set, training_data, method):
        # implement this function
        self.tree = self.train(data_set, training_data, training_data, training_data.columns[:-1], method)
        return(self.tree)

    # implement this function
    def classify(self, test_instance, tree_dict):
        default = 0 # baseline: always classifies as 0
        for key in list(test_instance.keys()):
            if key in list(tree_dict.keys()):
                try:
                    result = tree_dict[key][test_instance[key]] 
                except:
                    return default
                
                result = tree_dict[key][test_instance[key]]
                if isinstance(result,dict):
                    return self.classify(test_instance, result)
                else:
                    return result
    
    def print(self):
        print(self.tree)
       
def run_decision_tree():

    # Load data set
    with open("wine-dataset.csv") as f:
        next(f, None)
        data = [tuple(line) for line in csv.reader(f, delimiter=",")]
    print ("Number of records: %d" % len(data))

    # Split training/test sets
    # You need to modify the following code for cross validation.
    K = 10
    accuracy_set1 = [0,0,0,0,0,0,0,0,0,0]
    accuracy_set2 = [0,0,0,0,0,0,0,0,0,0]
    for j in range(0,10):
        training_set = [x for i, x in enumerate(data) if i % K != j]
        test_set = [x for i, x in enumerate(data) if i % K == j]
    
        data_set = pd.DataFrame(data, columns = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates','alcohol','quality'])
        #training_data = data_set.sample(frac=0.9, weights='quality', random_state=1)
        training_data = pd.DataFrame(training_set, columns = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates','alcohol','quality'])
        test_data = pd.DataFrame(test_set, columns = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates','alcohol','quality'])
        #print(data_set)
        #print(training_data)
        
        tree1 = DecisionTree()
        tree2 = DecisionTree()
        # Construct a tree using training set
        print("learning")
        tree_dict1 = tree1.learn( data_set, training_data, 'entropy')
        tree_dict2 = tree2.learn( data_set, training_data, 'giniIndex')
        
        test_data_dict = test_data.iloc[:,:].to_dict(orient = "records")
        feature_keys = ('fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates','alcohol')
    
        print("classifying")
        # Classify the test set using the tree we just constructed
        results1 = []
        results2 = []
        for i in range(len(test_data)):
            dict_item = test_data_dict[i]
            org_quality = dict_item.pop('quality')
            result1 = tree1.classify( dict_item, tree_dict1 )
            result2 = tree2.classify( dict_item, tree_dict2 )
            results1.append( result1 == org_quality)
            results2.append( result2 == org_quality)
    
        # Accuracy
        accuracy1 = float(results1.count(True))/float(len(results1))
        accuracy2 = float(results2.count(True))/float(len(results2))
        accuracy_set1[j] = accuracy1
        accuracy_set2[j] = accuracy2
        print ("entropy_accuracy %d: %.4f" % (j, accuracy1))
        print ("giniIndex_accuracy %d: %.4f" % (j, accuracy2))
        f = open(myname+"result.txt", "a")
        f.write("\nentropy_accuracy %d: %.4f" % (j, accuracy1))
        f.write("\nginiIndex_accuracy %d: %.4f" % (j, accuracy2))
        f.close()
       
    sum1 = 0
    sum2 = 0
    for j in range(0,10):
        sum1 = sum1 + accuracy_set1[j]
        sum2 = sum2 + accuracy_set2[j]
    
    print("average entropy accuracy: %.4f" % (sum1/10))
    print("average giniIndex accuracy: %.4f" % (sum2/10))
    # Writing results to a file (DO NOT CHANGE)
    f = open(myname+"result.txt", "a")
    f.write("\naverage entropy accuracy: %.4f" % (sum1/10))
    f.write("\naverage giniIndex accuracy: %.4f" % (sum2/10))
    f.close()

if __name__ == "__main__":
    run_decision_tree()
