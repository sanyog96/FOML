import time
import numpy as np
import pandas as pd
import math
from sklearn.model_selection import KFold, cross_val_score, train_test_split
from sklearn.ensemble import RandomForestRegressor,  GradientBoostingRegressor
import warnings
warnings.filterwarnings("ignore")

train_df = pd.read_csv('train.csv', nrows = 100000, parse_dates=["pickup_datetime"], index_col = "key")
#train_df.info()
test_df = pd.read_csv('test.csv', parse_dates=["pickup_datetime"])

def minkowski_distance(x1, x2, y1, y2, p):
    return ((abs(x2 - x1) ** p) + (abs(y2 - y1)) ** p) ** (1 / p)

def clean_data(df):
    df = df.dropna()
    #df[df['fare_amount'] > 600]['fare_amount'].value_counts()
    #df[df['fare_amount'] > 0]['fare_amount'].value_counts()

    df["year"] = df["pickup_datetime"].dt.year
    df["month"] = df["pickup_datetime"].dt.month
    df['week'] = df["pickup_datetime"].dt.week
    df["day"] = df["pickup_datetime"].dt.day
    df["hour"] = df["pickup_datetime"].dt.hour
    df["dayofweek"] = df["pickup_datetime"].dt.dayofweek
    df['dayofyear'] = df["pickup_datetime"].dt.dayofyear
    df["quarter"] = df["pickup_datetime"].dt.quarter
    df['weekofyear'] = df["pickup_datetime"].dt.weekofyear

    df['longitude_distance'] = abs(df["dropoff_longitude"] - df["pickup_longitude"])
    df['latitude_distance'] = abs(df["dropoff_latitude"] - df["pickup_latitude"])
    
    df['manhattan'] = minkowski_distance(df['pickup_longitude'], df['dropoff_longitude'],df['pickup_latitude'], df['dropoff_latitude'], 1)
    df['euclidean'] = minkowski_distance(df['pickup_longitude'], df['dropoff_longitude'],df['pickup_latitude'], df['dropoff_latitude'], 2)
    
    df["distance"] = df['longitude_distance'] + df['latitude_distance']
    df['distance_travelled'] = (df['longitude_distance'] ** 2 + df['latitude_distance'] ** 2) ** .5
    df['distance_travelled_sin'] = np.sin((df['longitude_distance'] ** 2 * df['latitude_distance'] ** 2) ** .5)
    df['distance_travelled_cos'] = np.cos((df['longitude_distance'] ** 2 * df['latitude_distance'] ** 2) ** .5)
    df['distance_travelled_sin_sqrd'] = np.sin((df['longitude_distance'] ** 2 * df['latitude_distance'] ** 2) ** .5) ** 2
    df['distance_travelled_cos_sqrd'] = np.cos((df['longitude_distance'] ** 2 * df['latitude_distance'] ** 2) ** .5) ** 2
    
    d_lon = df['pickup_longitude'] - df['dropoff_longitude']
    d_lat = df['pickup_latitude'] - df['dropoff_latitude']
    result = np.zeros(len(d_lon))
    l = np.sqrt(d_lon**2 + d_lat**2)
    result[d_lon>0] = (180/np.pi)*np.arcsin(d_lat[d_lon>0]/l[d_lon>0])
    idx = (d_lon<0) & (d_lat>0)
    result[idx] = 180 - (180/np.pi)*np.arcsin(d_lat[idx]/l[idx])
    idx = (d_lon<0) & (d_lat<0)
    result[idx] = -180 - (180/np.pi)*np.arcsin(d_lat[idx]/l[idx])
    df['direction'] = result
    
    df = df[(df.pickup_longitude > -80) & (df.pickup_longitude < -70) &
       (df.pickup_latitude > 35) & (df.pickup_latitude < 45) &
       (df.dropoff_longitude > -80) & (df.dropoff_longitude < -70) &
       (df.dropoff_latitude > 35) & (df.dropoff_latitude < 45)]
    #label = df["fare_amount"]
    #features_drop = ['dropoff_latitude', 'pickup_latitude', 'dropoff_longitude', 'pickup_longitude', 'pickup_datetime', 'fare_amount']
    
    #df.drop(features_drop, axis = 1, inplace=True)
    #df.info()
    return df

train_df = clean_data(train_df)
test_df = clean_data(test_df)

train_label = train_df["fare_amount"]
train_df.drop(['pickup_datetime', 'fare_amount'], axis = 1, inplace=True)
temp = test_df['key']
test_df.drop(['key','pickup_datetime'], axis = 1, inplace=True)

'''
n_folds = 5

def rmsle_cv(model):
    kf = KFold(n_folds, shuffle=True, random_state=45).get_n_splits(train_df)
    rmse= np.sqrt(-cross_val_score(model, train_df, train_label, scoring="neg_mean_squared_error", cv = kf))
    return(rmse)
'''

model5 = RandomForestRegressor(n_estimators=1000, max_depth=10, max_features='sqrt', random_state=5)
model5.fit(train_df, train_label)
prediction1 = model5.predict(test_df)
Submission1 = pd.DataFrame(data = prediction1,columns = ['fare_amount'])
Submission1['key'] = temp
Submission1 = Submission1[['key','fare_amount']]
Submission1.set_index('key', inplace = True)
Submission1.to_csv('q6_Submission1.csv')
#rmse5 = rmsle_cv(model5)
#print(rmse5.mean()) 

GBoost = GradientBoostingRegressor(n_estimators=3000, learning_rate=0.04, max_depth=10, max_features='sqrt', random_state =45)
GBoost.fit(train_df, train_label)
prediction2 = GBoost.predict(test_df)
Submission2 = pd.DataFrame(data = prediction2,columns = ['fare_amount'])
Submission2['key'] = temp
Submission2 = Submission2[['key','fare_amount']]
Submission2.set_index('key', inplace = True)
Submission2.to_csv('q6_Submission2.csv')
#rmse4 = rmsle_cv(GBoost)
#print(rmse4.mean()) #4.04