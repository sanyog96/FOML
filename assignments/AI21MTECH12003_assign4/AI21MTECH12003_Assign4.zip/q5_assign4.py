#Below code uses P = exp(wx+b)/(1+exp(wx+b))
import numpy as np
import pandas as pd
from math import exp
    
def accuracy(predictions, labels):
    accuracy = 0
    predictions = predictions.T
    labels = labels.T
    for i in range(len(predictions[0])):
        if predictions[0][i] == labels[0][i]:
            accuracy += 1
    return (accuracy / len(predictions[0]))

# Method to make predictions
def predict(X, b0, b1):
    temp = b0 + np.dot(X.T,b1)
    predictions = np.array([1 / (1 + exp(-1*i)) for i in temp])
    predictions = np.array([[1 if p >= 0.5 else 0 for p in predictions]]).T
    return predictions

# Method to train the model where X is the set of all features, Y is label, L is learning rate and epochs 
def logistic_regression(X, Y, L, epochs):

    m, n = X.shape
    
    # Initializing variables
    b0 = np.asmatrix(np.zeros(n)).T
    b1 = np.asmatrix(np.zeros(m)).T

    for epoch in range(epochs):
        y_pred = predict(X, b0, b1)
        D_b0 = np.sum((y_pred - train_label))  # Derivative of cross entropy loss wrt b0
        D_b1 = np.sum(np.dot((X),(y_pred - train_label)))
        # Update b0 and b1
        b0 = b0 - L * D_b0
        b1 = b1 - L * D_b1
    
    return b0, b1

'''
#Below can be used on any set of data available in 2D array format
train_feature and test_feature -> m*n
b0 -> n*1
b1 -> m*1
train_label and test_label -> n*1
b0, b1 = logistic_regression(train_features, train_labels, learning_rate, epochs)
predictions = predict(test_features, b0, b1)
accuracy(predictions, test_labels)
'''